package com.mindfull.ptest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PTestApplication.class, args);
	}

}
