package com.mindfull.ptest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
